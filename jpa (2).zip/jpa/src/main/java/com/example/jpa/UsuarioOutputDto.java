package com.example.jpa;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import java.util.Date;

@Data
@NoArgsConstructor
public class UsuarioOutputDto {

    int id_persona;
    String user;
    String password;
    String name;
    String surname;
    String company_email;
    String personal_email;
    String city;
    Boolean active;
    Date created_date;


    /*public UsuarioOutputDto(Usuario u) {
        if (u==null)
            return null;
            UsuarioOutputDto u = new UsuarioOutputDto();
        this.setNombre(u.getNombre);
    }*/

}
