package com.example.jpa;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;


public interface UsuarioRepositorio extends JpaRepository<Usuario, Integer> {

    @Query("select u from Usuario u where u.user = ?1")
    List<Usuario> getByName(String name);

    //Se podia usar directamente esto en lugar del getByName
    List<Usuario> findByName(String name);

}
