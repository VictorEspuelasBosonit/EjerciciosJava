Proyecto que explica como crear errores HTTP personalizados en Spring Boot.

Existe un documento explicando el proyecto en detalle en http://www.profesor-p.com/2018/11/20/personalizar-codigo-http-en-spring-boot/

